import argparse,json,math,re,statistics,time
from pathlib import Path
import requests
def hit(r,g,k): return int(bool(set(r[:k])&set(g)))
def recall(r,g,k): return len(set(r[:k])&set(g))/len(set(g)) if g else 0
def mrr(r,g,k):
 g=set(g)
 for i,x in enumerate(r[:k],1):
  if x in g:return 1/i
 return 0
def ndcg(r,g,k):
 g=set(g); dcg=sum(1/math.log2(i+1) for i,x in enumerate(r[:k],1) if x in g); n=min(k,len(g)); idcg=sum(1/math.log2(i+1) for i in range(1,n+1)); return dcg/idcg if idcg else 0
def cp(r,g,k): return sum(x in set(g) for x in r[:k])/len(r[:k]) if r[:k] else 0
def norm(s): return re.sub(r'[^a-z0-9\s]','',s.lower()).split()
def em(a,b): return int(norm(a)==norm(b))
def f1(a,b):
 from collections import Counter
 A,B=Counter(norm(a)),Counter(norm(b)); o=sum((A&B).values())
 if not o:return 0
 p=o/sum(A.values()); q=o/sum(B.values()); return 2*p*q/(p+q)
def pct(v,p):
 v=sorted(v); return v[min(len(v)-1,math.ceil(p/100*len(v))-1)] if v else None
a=argparse.ArgumentParser(); a.add_argument('--dataset',default='eval/questions.jsonl'); a.add_argument('--base-url',default='http://127.0.0.1:8000'); a.add_argument('--output',default='eval/results.json'); a.add_argument('--k',type=int,default=5); x=a.parse_args()
rows=[json.loads(z) for z in Path(x.dataset).read_text().splitlines() if z.strip()]; rec=[]; rlat=[]; elat=[]
for q in rows:
 t=time.perf_counter(); d=requests.post(x.base_url+'/query',json={'question':q['question'],'k':x.k},timeout=180).json(); elapsed=(time.perf_counter()-t)*1000; got=[c['id'] for c in d['chunks']]; gold=q['relevant_chunk_ids']; rlat.append(d['retrieval_latency_ms']); elat.append(elapsed)
 rec.append({'id':q['id'],'question':q['question'],'context':'\n\n'.join(c['text'] for c in d['chunks']),'answer':d['answer'],'citations':d['citations'],'hit_at_k':hit(got,gold,x.k),'recall_at_k':recall(got,gold,x.k),'mrr':mrr(got,gold,x.k),'ndcg_at_k':ndcg(got,gold,x.k),'context_precision_at_k':cp(got,gold,x.k),'retrieval_latency_ms':d['retrieval_latency_ms'],'generation_latency_ms':d['generation_latency_ms'],'gold_answer':q.get('gold_answer'),'exact_match':em(d['answer'],q['gold_answer']) if q.get('gold_answer') else None,'f1':f1(d['answer'],q['gold_answer']) if q.get('gold_answer') else None})
def avg(k):
 v=[z[k] for z in rec if z[k] is not None]; return statistics.mean(v) if v else None
out={'n_questions':len(rec),'k':x.k,'retrieval':{k:avg(k) for k in ['hit_at_k','recall_at_k','mrr','ndcg_at_k','context_precision_at_k']},'answer':{'exact_match':avg('exact_match'),'f1':avg('f1'),'faithfulness_llm_judge':None,'answer_relevance_llm_judge':None},'latency_ms':{'retrieval_p50':pct(rlat,50),'retrieval_p95':pct(rlat,95),'end_to_end_p50':pct(elat,50),'end_to_end_p95':pct(elat,95)},'per_question':rec}
Path(x.output).write_text(json.dumps(out,indent=2)); print(json.dumps(out['retrieval'],indent=2)); print(json.dumps(out['latency_ms'],indent=2))
