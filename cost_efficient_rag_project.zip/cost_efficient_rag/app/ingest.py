from pathlib import Path
import hashlib,re,chromadb,markdown
from bs4 import BeautifulSoup
from sentence_transformers import SentenceTransformer
from .config import settings

def doc_id(source): return hashlib.sha256(source.strip().encode()).hexdigest()[:24]
def read_source(p):
    s=p.suffix.lower()
    if s=='.pdf':
        import fitz
        d=fitz.open(p); return '\n'.join(x.get_text() for x in d),'pdf'
    if s in {'.html','.htm'}:
        soup=BeautifulSoup(p.read_text(encoding='utf8',errors='ignore'),'html.parser')
        for x in soup(['script','style','noscript']): x.decompose()
        return soup.get_text('\n',strip=True),'html'
    if s in {'.md','.markdown'}:
        soup=BeautifulSoup(markdown.markdown(p.read_text(encoding='utf8',errors='ignore')),'html.parser')
        return soup.get_text('\n',strip=True),'md'
    raise ValueError(f'Unsupported: {p}')
def chunk_text(text,size,overlap):
    text=re.sub(r'[ \t]+',' ',text.replace('\r','\n')); text=re.sub(r'\n{3,}','\n\n',text).strip()
    out=[]; start=0
    while start<len(text):
        end=min(len(text),start+size)
        if end<len(text):
            b=max(text.rfind('\n',start,end),text.rfind(' ',start,end))
            if b>start+int(size*.6): end=b
        if text[start:end].strip(): out.append(text[start:end].strip())
        if end>=len(text): break
        start=max(end-overlap,start+1)
    return out
def collection():
    return chromadb.PersistentClient(path=settings.chroma_dir).get_or_create_collection(name=settings.collection_name,metadata={'hnsw:space':'cosine'})
def ingest_file(p,model):
    text,stype=read_source(p); source=str(p.resolve()); did=doc_id(source); chunks=chunk_text(text,settings.chunk_size,settings.chunk_overlap); c=collection()
    try: c.delete(where={'doc_id':did})
    except Exception: pass
    if not chunks: return {'source':source,'doc_id':did,'chunks':0}
    vec=model.encode(chunks,normalize_embeddings=True,show_progress_bar=False)
    ids=[f'{did}:{i}' for i in range(len(chunks))]
    meta=[{'doc_id':did,'source':source,'source_type':stype,'chunk_index':i} for i in range(len(chunks))]
    c.add(ids=ids,documents=chunks,embeddings=vec.tolist(),metadatas=meta)
    return {'source':source,'doc_id':did,'chunks':len(chunks)}
def ingest_path(path):
    p=Path(path); files=[p] if p.is_file() else sorted(x for x in p.rglob('*') if x.is_file() and x.suffix.lower() in {'.pdf','.html','.htm','.md','.markdown'})
    m=SentenceTransformer(settings.embed_model); return [ingest_file(x,m) for x in files]
