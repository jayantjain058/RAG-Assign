import time
from dataclasses import dataclass
from sentence_transformers import SentenceTransformer
from .config import settings
from .ingest import collection
@dataclass
class Hit: id:str; text:str; score:float; metadata:dict
class Retriever:
    def __init__(self): self.model=SentenceTransformer(settings.embed_model); self.c=collection()
    def search(self,q,k=None,where=None):
        t=time.perf_counter(); k=k or settings.top_k; v=self.model.encode([q],normalize_embeddings=True)[0]
        kw={'query_embeddings':[v.tolist()],'n_results':k}
        if where: kw['where']=where
        r=self.c.query(**kw); ms=(time.perf_counter()-t)*1000
        ids=r.get('ids',[[]])[0]; docs=r.get('documents',[[]])[0]; meta=r.get('metadatas',[[]])[0]; dist=r.get('distances',[[]])[0]
        return [Hit(ids[i],docs[i],1-float(dist[i]),meta[i]) for i in range(len(ids))],ms
