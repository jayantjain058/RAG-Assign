import os
from dataclasses import dataclass
from dotenv import load_dotenv
load_dotenv()
@dataclass(frozen=True)
class Settings:
    chroma_dir: str=os.getenv('CHROMA_DIR','./storage/chroma')
    collection_name: str=os.getenv('COLLECTION_NAME','rag_chunks')
    embed_model: str=os.getenv('EMBED_MODEL','sentence-transformers/all-MiniLM-L6-v2')
    chunk_size: int=int(os.getenv('CHUNK_SIZE','700'))
    chunk_overlap: int=int(os.getenv('CHUNK_OVERLAP','120'))
    top_k: int=int(os.getenv('TOP_K','5'))
    min_similarity: float=float(os.getenv('MIN_SIMILARITY','0.25'))
    llm_provider: str=os.getenv('LLM_PROVIDER','openai').lower()
    openai_model: str=os.getenv('OPENAI_MODEL','gpt-4o-mini')
    ollama_base_url: str=os.getenv('OLLAMA_BASE_URL','http://localhost:11434')
    ollama_model: str=os.getenv('OLLAMA_MODEL','llama3.2:3b')
settings=Settings()
assert settings.chunk_overlap < settings.chunk_size
