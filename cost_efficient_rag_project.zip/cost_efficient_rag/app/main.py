import re,time
from fastapi import FastAPI,HTTPException
from pydantic import BaseModel,Field
from .config import settings
from .retrieval import Retriever
from .llm import generate
app=FastAPI(title='Cost-Efficient RAG',version='1.0')
r=Retriever()
class Query(BaseModel): question:str; k:int=Field(default=settings.top_k,ge=1,le=50); filter:dict|None=None
@app.get('/health')
def health(): return {'status':'ok'}
@app.post('/query')
def query(x:Query):
    t=time.perf_counter()
    if x.filter and any(k not in {'source_type','doc_id'} for k in x.filter): raise HTTPException(400,'Allowed filters: source_type, doc_id')
    hits,rt=r.search(x.question,x.k,x.filter); usable=[h for h in hits if h.score>=settings.min_similarity]
    if not usable: return {'answer':'I do not have enough information in the retrieved context to answer that.','citations':[],'chunks':[],'retrieved_chunk_count':len(hits),'retrieval_latency_ms':round(rt,2),'generation_latency_ms':0,'total_latency_ms':round((time.perf_counter()-t)*1000,2),'token_usage':None}
    z=generate(x.question,usable); cited=re.findall(r'\[([^\]]+)\]',z.answer); valid={h.id for h in usable}; citations=[c for c in cited if c in valid] or [h.id for h in usable]
    return {'answer':z.answer,'citations':citations,'chunks':[{'id':h.id,'score':round(h.score,4),'text':h.text,'metadata':h.metadata} for h in hits],'retrieved_chunk_count':len(hits),'retrieval_latency_ms':round(rt,2),'generation_latency_ms':round(z.latency_ms,2),'total_latency_ms':round((time.perf_counter()-t)*1000,2),'token_usage':{'input':z.input_tokens,'output':z.output_tokens,'total':z.total_tokens}}
