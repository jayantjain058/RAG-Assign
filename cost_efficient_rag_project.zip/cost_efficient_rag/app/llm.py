import time
from dataclasses import dataclass
from .config import settings
@dataclass
class LLMResult: answer:str; input_tokens:int|None; output_tokens:int|None; total_tokens:int|None; latency_ms:float
SYSTEM=('You are a strict retrieval-grounded QA assistant. Answer only from the supplied context. '
        'If the context is insufficient, say: I do not have enough information in the retrieved context to answer that. '
        'Every factual claim must cite one or more supplied chunk IDs as [chunk_id]. Do not invent facts or citations.')
def prompt(q,chunks): return 'Question: '+q+'\n\nContext:\n'+'\n\n'.join('CHUNK '+c.id+'\n'+c.text for c in chunks)+'\n\nAnswer concisely and cite factual claims using exact chunk IDs.'
def generate(q,chunks):
    t=time.perf_counter(); p=prompt(q,chunks)
    if settings.llm_provider=='ollama':
        import requests
        r=requests.post(settings.ollama_base_url+'/api/chat',json={'model':settings.ollama_model,'stream':False,'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':p}]},timeout=120); r.raise_for_status(); d=r.json(); a=d['message']['content']; i=d.get('prompt_eval_count'); o=d.get('eval_count'); return LLMResult(a,i,o,i+o if i is not None and o is not None else None,(time.perf_counter()-t)*1000)
    from openai import OpenAI
    r=OpenAI().chat.completions.create(model=settings.openai_model,temperature=0,messages=[{'role':'system','content':SYSTEM},{'role':'user','content':p}]); u=r.usage; i=getattr(u,'prompt_tokens',None); o=getattr(u,'completion_tokens',None); total=getattr(u,'total_tokens',None); return LLMResult(r.choices[0].message.content,i,o,total,(time.perf_counter()-t)*1000)
