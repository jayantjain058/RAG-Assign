import argparse,json
from app.ingest import ingest_path
p=argparse.ArgumentParser(); p.add_argument('path'); a=p.parse_args()
for x in ingest_path(a.path): print(json.dumps(x))
